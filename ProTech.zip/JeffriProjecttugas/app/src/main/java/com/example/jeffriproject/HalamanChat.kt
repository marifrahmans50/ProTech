package com.example.jeffriproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.Toast

class HalamanChat : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_chat)
        title  =  "Chat"

        val btnSendMessage: ImageButton = findViewById(R.id.send_message)
        btnSendMessage.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        if (v != null) {
            when (v.id) {
                R.id.send_message -> {
                    Toast.makeText(this, "Pesan Telah Terkirim", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}