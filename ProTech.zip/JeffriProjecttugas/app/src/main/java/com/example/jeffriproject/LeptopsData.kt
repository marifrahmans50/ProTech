package com.example.jeffriproject

object LeptopsData {
    private val leptopName = arrayOf("Huawei Matebook X Pro",
        "Macbook Pro 13 inci Touchbar",
        "MacBook Air",
        "Lenovo Thinkpad X1 Carbon",
        "Lenovo Ideapad 530s",
        "XPS 13",
        "Inspiron 7000",
        "Spectre 13",
        "Pavillion 360",
        "Acer Swift 7")

    private val leptopDetails = arrayOf("Kami merekomendasikan pilihan ini sebagai laptop terbaik yang bisa kamu miliki." +
            "Pasalnya, laptop tersebut memiliki desain cantik dan material yang kokoh. Kemudian layarnya nyaris tanpa bezel dan terlihat terang. Bodinya terbuat dari bahan alumunium dan dirancang unibody. Bobotnya pun ringan.",
    "Seperti Macbook Pro lainnya, tipe yang satu ini juga punya kekuatan pemrosean tinggi." +
            "Desainnya pun secara keseluruhan masih sama. Tambahan terbaru yang menarik untuk kamu coba adalah Touch Bar di bagian atas keyboard.",
    "Tipe yang satu ini merupakan pembaruan yang sudah lama dinantikan kehadirannya oleh para pengguna Macbook Air." +
            " Desainnya masih mirip, yaitu tipis, ringan dan memiliki kinerja mumpuni. Hal menariknya, pada tipe baru ini terdapat kelebihan berupa sensor pemindai sidik jari, Retina Display yang lebih rapat, serta Butterflu keyboard yang dijanjikan tidak rawan.",
    "Ini merupakan Thinkpad generasi 6 yang rilis di sekitar 2018 dan didaulat sebagai laptop bisnis terbaik di CES tahun tersebut." +
            "Gelar itu memang tidak salah. Sejak generasi pertamanya, Thinkpad merupakan lini produk yang dibuat dengan material kelas atas, dibekali sistem keamanan canggih, keyboard yang sangat nyaman serta bobot ringan.",
    "BukaReview memasukkan Lenovo 530s dalam daftar ini karena desainnya yang cantik dan pilihan spesifikasinya yang pas untuk kamu pakai bekerja hingga bermain." +
            "Seperti laptop kelas menengah umumnya, kamu cuma bisa memakai laptop ini untuk mengetik, membuka aplikasi grafis yang tidak terlalu menuntut dan bermain game casual.",
    "Seperti sudah disebutkan, laptop seri XPS merupakan salah satu dambaan pengguna." +
            " Hal ini karena desainnya yang cantik nyaris tanpa bezel. Spesifikasinya pun cukup tinggi, dan tetap memiliki bobot ringan. Kekurangannya adalah masih menggunakan kartu grafis internal Intel HD 620",
    "Dell Inspiron 7000 seri 2018 bisa dibilang sebagai versi mini dari XPS 15 sekaligus berada di lini mid-high. " +
            "Kinerjanya tangguh, layarnya nyaris bezelless, bisa ditekuk dan Kamu juga bisa mendapatkan variasi spesifikasi cukup luas dari harga termurah hingga termahalnya.",
    "Desain laptop ini sangat mempesona. Layarnya terlihat luas karena dikelilingi bezel tipis, bobotnya tidak membuat punggung pegal-pegal, dan pilihan spesifikasinya menjamin kinerja mumpuni. ",
    "Laptop ini di masing-masing serinya dibekali kekuatan pemrosesan Intel Core generasi ke-8, juga teknologi HP Fast Charge yang bikin pengisian daya jadi sangat cepat. Kamu juga bisa menekuknya hingga 360 derajat." +
            "    \"Laptop ini di masing-masing serinya dibekali kekuatan pemrosesan Intel Core generasi ke-8, juga teknologi HP Fast Charge yang bikin pengisian daya jadi sangat cepat. Kamu juga bisa menekuknya hingga 360 derajat.",
    "Tipe laptop satu ini bisa disebut-sebut sebagai laptop paling tipis di dunia dengan ukuran ketebalan 8,98 mm." +
            "Selain itu kamu juga mendapatkan layar ukuran 14 inci, backlit keyboard, serta sensor sidik jari.")

    private val leptopsImages = intArrayOf(R.drawable.laptop1,
    R.drawable.laptop2,
    R.drawable.laptop3,
    R.drawable.laptop4,
    R.drawable.laptop5,
    R.drawable.laptop6,
    R.drawable.laptop7,
    R.drawable.laptop8,
    R.drawable.laptop9,
    R.drawable.laptop10)

    private val diskonName = arrayOf(
            "Diskon Produk HP",
            "Cashback Hingga 300rb",
            "Diskon Hemat",
            "Paket Study From Home",
            "Promo Laptop Gaming",
            "Cashback Acer Series",
            "Free Game AMD APU A8",
            "PC ASUS Touchscreen",
            "Free Tas Selempang",
            "Lenovo Ideapad High Performance")

    private val diskonDetails = arrayOf(
            "Pesta Diskon HP Hingga 40%. Promo terbatas. Untuk Ketentuan lebih lanjut silahkan baca dideskripsi.",
            "Cashbak Produk HP hingga 300RB dan Free Tas Laptop. Dijamin original, terpercaya, dan garansi.",
            "Diskon hingga 500ribu dengan menggunakan kode voucher. Ketentuan lebih lanjut silahkan baca dideskripsi.",
            "Belajar dirumah jadi lebih efektif dengan paket laptop, printer, mouse, dan usb. Paket hemat hingga 2 juta.",
            "Main game jadi lebih menyenangkan dan anti lag dengan laptop gaming terbaik dengan harga istimewa. Dilengkapi dengan CPU yang handal untuk menjalankan game berat.",
            "Pilihan laptop Acer Series dengan cashback yang menarik. Ketentuan lebih lanjut silahkan baca dideskripsi.",
            "Dapatkan game secara gratis dengan pembelian Notebook AMD APU A8. Ketentuan lebih lanjut silahkan baca dideskripsi.",
            "PC canggih dengan tampilan elegant dan modern dengan harga terbaik. Dilengkapi dengan processor yang mumpuni untuk setiap aplikasi.",
            "Free tas selempang setiap pembelian laptop HP. Ketentuan lebih lanjut silahkan baca dideskripsi.",
            "Tampilan elegant dan slim Lenovo s340 yang nyaman dengan free tas selempang dan microsoft office. Ketentuan lebih lanjut silahkan baca dideskripsi.")

    private val diskonImages = intArrayOf(
            R.drawable.diskon1,
            R.drawable.diskon2,
            R.drawable.diskon3,
            R.drawable.diskon4,
            R.drawable.diskon5,
            R.drawable.diskon6,
            R.drawable.diskon7,
            R.drawable.diskon8,
            R.drawable.diskon9,
            R.drawable.diskon10)

    val listData: ArrayList<Leptop>
    get() {
        val list = arrayListOf<Leptop>()
        for  (position  in  leptopName.indices)  {
            val  leptop =  Leptop()
            leptop.name  =  leptopName[position]
            leptop.detail  =  leptopDetails[position]
            leptop.photo  =  leptopsImages[position]
            leptop.namediskon  =  diskonName[position]
            leptop.detaildiskon  =  diskonDetails[position]
            leptop.photodiskon  =  diskonImages[position]
            list.add(leptop)
        }
        return  list
    }

}