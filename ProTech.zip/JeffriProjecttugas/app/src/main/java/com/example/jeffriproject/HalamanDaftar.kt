package com.example.jeffriproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase

class HalamanDaftar : AppCompatActivity() {
    private lateinit var edtPassword: EditText
    private lateinit var edtUser: EditText
    private lateinit var btnLogin: Button
    private lateinit var edtPassword1: EditText
    private lateinit var edtNama: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_daftar)
        supportActionBar?.hide()

        edtUser = findViewById(R.id.edt_user)
        edtPassword = findViewById(R.id.edt_password)
        edtNama = findViewById(R.id.edt_nama)
        edtPassword1 = findViewById(R.id.edt_password1)
        btnLogin = findViewById(R.id.btn_login)
        btnLogin.setOnClickListener {
            saveData()
        }
    }
    private fun saveData() {
        val password1 = edtPassword1.text.toString().trim()
        val nama = edtNama.text.toString().trim()
        val password = edtPassword.text.toString().trim()
        val user = edtUser.text.toString().trim()
        var isEmptyFields = false
        if (user.isEmpty()) {
            edtUser.error = "Anda Harus Memasukkan Username"
            return
        }
        if (password.isEmpty()) {
            edtPassword.error = "Anda Harus Memasukkan Password"
            return
        }
        if (nama.isEmpty()) {
            edtNama.error = "Anda Harus Memasukkan Nama"
            return
        }
        if (password1.isEmpty()) {
            edtPassword1.error = "Ketik Ulang Password"
            return
        }

        val ref = FirebaseDatabase.getInstance().getReference("User")
        val userId = ref.push().key
        val usr = User(userId, user, nama, password)

        if (userId != null) {
            ref.child(userId).setValue(usr).addOnCompleteListener {
                Toast.makeText(applicationContext, "Data berhasil ditambahkan", Toast.LENGTH_SHORT).show()
            }
        }
    }
    }
