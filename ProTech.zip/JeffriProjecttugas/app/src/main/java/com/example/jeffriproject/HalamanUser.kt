package com.example.jeffriproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView

class HalamanUser : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_user)
        title = "User"

        val btnHome: ImageView = findViewById(R.id.btn_home)
        btnHome.setOnClickListener(this)
        val btnPromo: ImageView = findViewById(R.id.btn_image)
        btnPromo.setOnClickListener(this)
        val btnCart: ImageView = findViewById(R.id.btn_cart)
        btnCart.setOnClickListener(this)
        val btnUser: ImageView = findViewById(R.id.btn_user)
        btnUser.setOnClickListener(this)
        val tvHome: TextView = findViewById(R.id.tv_home)
        tvHome.setOnClickListener(this)
        val tvPromo: TextView = findViewById(R.id.tv_image)
        tvPromo.setOnClickListener(this)
        val tvCart: TextView = findViewById(R.id.tv_cart)
        tvCart.setOnClickListener(this)
        val tvUser: TextView = findViewById(R.id.tv_user)
        tvUser.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        if (v != null) {
            when (v.id) {
                R.id.btn_home -> {
                    val moveIntent = Intent(this@HalamanUser, MainActivity::class.java)
                    startActivity(moveIntent)
                }
                R.id.btn_image -> {
                    val moveIntent = Intent(this@HalamanUser, HalamanImage::class.java)
                    startActivity(moveIntent)
                }
                R.id.btn_cart -> {
                    val moveIntent = Intent(this@HalamanUser, HalamanCart::class.java)
                    startActivity(moveIntent)
                }
                R.id.btn_user -> {
                    val moveIntent = Intent(this@HalamanUser, HalamanUser::class.java)
                    startActivity(moveIntent)
                }
                R.id.tv_home -> {
                    val moveIntent = Intent(this@HalamanUser, MainActivity::class.java)
                    startActivity(moveIntent)
                }
                R.id.tv_image -> {
                    val moveIntent = Intent(this@HalamanUser, HalamanImage::class.java)
                    startActivity(moveIntent)
                }
                R.id.tv_cart -> {
                    val moveIntent = Intent(this@HalamanUser, HalamanCart::class.java)
                    startActivity(moveIntent)
                }
                R.id.tv_user -> {
                    val moveIntent = Intent(this@HalamanUser, HalamanUser::class.java)
                    startActivity(moveIntent)
                }
            }
        }
    }
}
