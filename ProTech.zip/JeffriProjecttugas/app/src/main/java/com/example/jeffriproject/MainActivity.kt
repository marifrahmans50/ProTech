package com.example.jeffriproject

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity(), View.OnClickListener,
	GridLeptopAdapter.OnitemClickListener, ListLeptopAdapter.OnItemClickListener {
	private  lateinit  var  rvLeptops: RecyclerView
	private  var  list:  ArrayList<Leptop>  =  arrayListOf()
	private  var  title:  String  =  "Beranda"
	private lateinit var btnSuara : Button
	private val RQ_SPEECH_REC = 102

	override  fun  onCreate(savedInstanceState:  Bundle?)  {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
		setActionBarTitle(title)

		val btnSpesifikasi: Button = findViewById(R.id.btn_spesifikasi)
		btnSpesifikasi.setOnClickListener(this)
		val btnHome: ImageView = findViewById(R.id.btn_home)
		btnHome.setOnClickListener(this)
		val btnPromo: ImageView = findViewById(R.id.btn_image)
		btnPromo.setOnClickListener(this)
		val btnCart: ImageView = findViewById(R.id.btn_cart)
		btnCart.setOnClickListener(this)
		val btnUser: ImageView = findViewById(R.id.btn_user)
		btnUser.setOnClickListener(this)
		val tvHome: TextView = findViewById(R.id.tv_home)
		tvHome.setOnClickListener(this)
		val tvPromo: TextView = findViewById(R.id.tv_image)
		tvPromo.setOnClickListener(this)
		val tvCart: TextView = findViewById(R.id.tv_cart)
		tvCart.setOnClickListener(this)
		val tvUser: TextView = findViewById(R.id.tv_user)
		tvUser.setOnClickListener(this)
		btnSuara = findViewById(R.id.btn_suara)

		rvLeptops  =  findViewById(R.id.rv_leptop)
		rvLeptops.setHasFixedSize(true)

		list.addAll(LeptopsData.listData)
		showRecyclerList()

		btnSuara.setOnClickListener {
			askSpeechInput()
		}
	}

	private fun askSpeechInput() {
		if(!SpeechRecognizer.isRecognitionAvailable(this)) {
			Toast.makeText(this, "Speech Recognition is not available", Toast.LENGTH_SHORT).show()
		} else {
			val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
			i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
			i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
			i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Katakan Sesuatu")
			startActivityForResult(i,RQ_SPEECH_REC)
		}
	}

	override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
		super.onActivityResult(requestCode, resultCode, data)

		if (requestCode == RQ_SPEECH_REC && resultCode == Activity.RESULT_OK) {
			val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
		}
	}

	override fun onClick(v: View?) {
		when (v?.id) {
			R.id.btn_spesifikasi -> {
				val moveIntent = Intent(this@MainActivity, HalamanSpesifikasi::class.java)
				startActivity(moveIntent)
			}
			R.id.btn_home -> {
				val moveIntent = Intent(this@MainActivity, MainActivity::class.java)
				startActivity(moveIntent)
			}
			R.id.btn_image -> {
				val moveIntent = Intent(this@MainActivity, HalamanImage::class.java)
				startActivity(moveIntent)
			}
			R.id.btn_cart -> {
				val moveIntent = Intent(this@MainActivity, HalamanCart::class.java)
				startActivity(moveIntent)
			}
			R.id.btn_user -> {
				val moveIntent = Intent(this@MainActivity, HalamanUser::class.java)
				startActivity(moveIntent)
			}
			R.id.tv_home -> {
				val moveIntent = Intent(this@MainActivity, MainActivity::class.java)
				startActivity(moveIntent)
			}
			R.id.tv_image -> {
				val moveIntent = Intent(this@MainActivity, HalamanImage::class.java)
				startActivity(moveIntent)
			}
			R.id.tv_cart -> {
				val moveIntent = Intent(this@MainActivity, HalamanCart::class.java)
				startActivity(moveIntent)
			}
			R.id.tv_user -> {
				val moveIntent = Intent(this@MainActivity, HalamanUser::class.java)
				startActivity(moveIntent)
			}
		}
	}


	private  fun  showRecyclerList()  {
		rvLeptops.layoutManager  =  LinearLayoutManager(this)
		rvLeptops.adapter = ListLeptopAdapter(list, this)
		list.addAll(LeptopsData.listData)

	}

	override  fun  onCreateOptionsMenu(menu: Menu):  Boolean  {
		menuInflater.inflate(R.menu.menu_main,  menu)
		return  super.onCreateOptionsMenu(menu)
	}

	override  fun  onOptionsItemSelected(item: MenuItem):  Boolean  {
		setMode(item.itemId)
		return  super.onOptionsItemSelected(item)
	}

	private  fun  setMode(selectedMode:  Int)  {
		when  (selectedMode)  {
		R.id.action_list  ->  {
			title  =  "Beranda"
			showRecyclerList()
		}

		R.id.action_grid  ->  {
			title  =  "Gambar Leptop"
			showRecyclerGrid()
		}

		R.id.action_cardview  ->  {
			title  =  "Item Leptop"
			showRecyclerCardView()
		}

			R.id.action_about  ->  {
				title  =  "About"
				val moveIntent = Intent(this@MainActivity, HalamanAbout::class.java)
				startActivity(moveIntent)
			}
			R.id.action_chat  ->  {
				title  =  "Chat"
				val moveIntent = Intent(this@MainActivity, HalamanChat::class.java)
				startActivity(moveIntent)
			}
			R.id.action_setting  ->  {
				Toast.makeText(this, "Anda memilih setting",Toast.LENGTH_SHORT).show()
			}
	}
		setActionBarTitle(title)
	}

	private  fun  showRecyclerGrid()  {
		rvLeptops.layoutManager  =  GridLayoutManager(this,  2)
		val  gridLeptopAdapter  =  GridLeptopAdapter(list,this)
		rvLeptops.adapter  =  gridLeptopAdapter

	}

	private  fun  showRecyclerCardView()  {
		rvLeptops.layoutManager  =  LinearLayoutManager(this)
		val  cardViewLeptopAdapter  =  CardViewLeptopAdapter(list)
		rvLeptops.adapter  =  cardViewLeptopAdapter
	}

	private  fun  setActionBarTitle(title:  String)  {
		if  (supportActionBar  !=  null)  {
			(supportActionBar  as ActionBar).title  =  title
		}
	}

	private  fun  showSelectedLeptop(leptop:  Leptop)  { Toast.makeText(this,  "Kamu  memilih  "  +  leptop.name,
		Toast.LENGTH_SHORT).show()
	}

	override fun onItemClick(data: Leptop) {
		val intent = Intent(this, HalamanDetail1::class.java)
		intent.putExtra("Nama_Leptop", data.name)
		intent.putExtra("Detail_Leptop", data.detail)
		intent.putExtra("Gambar_Leptop", data.photo)
		startActivity(intent)
	}

}


