package com.example.jeffriproject

data class Leptop(
    var name: String = "",
    var detail: String = "",
    var namediskon: String = "",
    var detaildiskon: String = "",
    var photodiskon: Int = 0,
    var photo: Int = 0
)