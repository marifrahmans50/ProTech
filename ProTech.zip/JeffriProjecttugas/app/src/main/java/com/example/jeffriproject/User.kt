package com.example.jeffriproject

data class User (
    val id : String? ,
    val nama : String ,
    val username : String ,
    val password : String
)