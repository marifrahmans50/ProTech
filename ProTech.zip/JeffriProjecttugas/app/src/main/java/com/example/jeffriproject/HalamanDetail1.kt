package com.example.jeffriproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class HalamanDetail1 : AppCompatActivity(), View.OnClickListener {
    private lateinit var btnBayar : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_detail1)

        val itemphoto1 = findViewById<ImageView>(R.id.gambar)
        val namaleptop1 = findViewById<TextView>(R.id.tv_leptop)
        val deskripsi1 = findViewById<TextView>(R.id.tv_detail)

        val itemphoto2 = intent.extras?.getInt("Gambar_Leptop")
        val namaleptop2 = intent.extras?.getString("Nama_Leptop")
        val deskripsi2 = intent.extras?.getString("Detail_Leptop")

        Glide
                .with(this)
                .load(itemphoto2)
                .centerCrop()
                .into(itemphoto1)

        namaleptop1.text = namaleptop2.toString()
        deskripsi1.text = deskripsi2.toString()

        val actionbar = supportActionBar
        actionbar!!.title = ""
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)

        val btnBayar: Button = findViewById(R.id.btn_bayar)
        btnBayar.setOnClickListener(this)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_bayar -> {
                val moveIntent = Intent(this@HalamanDetail1, HalamanCheckout::class.java)
                startActivity(moveIntent)
            }
        }
    }
}