package com.example.jeffriproject

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class  GridLeptopAdapter(val  listLeptops:  ArrayList<Leptop>, var ItemClickListener: MainActivity)
    : RecyclerView.Adapter<GridLeptopAdapter.GridViewHolder>()  {


    override  fun  onCreateViewHolder(viewGroup: ViewGroup, i:  Int): GridViewHolder  {
        val  view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_grid_leptop, viewGroup,  false)
        return  GridViewHolder(view)
    }

    override  fun  onBindViewHolder(holder:  GridViewHolder,  position:  Int)  {
        Glide.with(holder.itemView.context)
        .load(listLeptops[position].photo)
        .apply(RequestOptions().override(350,  550))
        .into(holder.imgPhoto)

       val leptop = listLeptops[position]

        holder.bind(leptop, ItemClickListener)
    }

    override  fun  getItemCount():  Int  {
        return  listLeptops.size
    }

    inner  class  GridViewHolder(itemView:  View)  : RecyclerView.ViewHolder(itemView)  {

        fun bind(leptop: Leptop, action: OnitemClickListener) {
            itemView.setOnClickListener {
                action.onItemClick(leptop)
            }
        }

        var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
    }

    interface  OnitemClickListener  {
        fun  onItemClick(leptop: Leptop)
    }

}
