package com.example.jeffriproject


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.lang.NumberFormatException

class HalamanCheckout : AppCompatActivity(), View.OnClickListener {
    private lateinit var edtHarga : EditText
    private lateinit var tvResult : TextView
    private lateinit var btnCalculate : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_checkout)

        edtHarga = findViewById(R.id.edt_harga)
        tvResult = findViewById(R.id.tv_result)
        btnCalculate = findViewById(R.id.btn_calculate)

        btnCalculate.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        val inputHarga = edtHarga.text.toString().trim()
        var isEmptyFields = false
        if (inputHarga.isEmpty()) {
            isEmptyFields = true
            edtHarga.error = "Anda Harus Memasukkan Harga"
        }
        val harga = toDouble(inputHarga)

        if (!isEmptyFields) {
            val checkout = harga as Double + 30000
            tvResult.text = checkout.toString()
        }
    }

    private fun toDouble(str: String): Double? {
        return try {
            str.toDouble()
        } catch (e: NumberFormatException) {
            null
        }
    }
}