package com.example.jeffriproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HalamanAbout : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_about)
        title = "About"
    }
}