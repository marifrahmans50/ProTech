package com.example.jeffriproject

import android.content.Intent
import android.os.Bundle

import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class HalamanLogin : AppCompatActivity(), View.OnClickListener {
    private lateinit var edtPassword: EditText
    private lateinit var edtUser: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnDaftar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_login)
        supportActionBar?.hide()

        edtUser = findViewById(R.id.edt_user)
        edtPassword = findViewById(R.id.edt_password)
        btnLogin = findViewById(R.id.btn_login)
        btnDaftar = findViewById(R.id.btn_daftar)
        btnLogin.setOnClickListener(this)
        btnDaftar.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_daftar-> {
                val moveIntent = Intent(this@HalamanLogin, HalamanDaftar::class.java)
                startActivity(moveIntent)
            }
        }
        val inputPassword = edtPassword.text.toString().trim()
        val inputUser = edtUser.text.toString().trim()
        var isEmptyFields = false
        if (inputUser.isEmpty()) {
            isEmptyFields = true
            edtUser.error = "Anda Harus Memasukkan Username"
        }
        if (inputPassword.isEmpty()) {
            isEmptyFields = true
            edtPassword.error = "Anda Harus Memasukkan Password"
        }

        if (!isEmptyFields) {
            when (v?.id) {
                R.id.btn_login -> {
                    val moveIntent = Intent(this@HalamanLogin, MainActivity::class.java)
                    startActivity(moveIntent)
                }
            }
        }
    }
}